import random
import time

from estimator import calculate_difficulty

def _build_raw_level_grid(target_difficulty, width=220, height=16, seed=None):
    if seed is not None:
        random.seed(seed)
    else:
        random.seed(time.time_ns() + random.randint(0, 1000000))

    diff = max(0.0, min(1.0, float(target_difficulty)))
    grid = [['-' for _ in range(width)] for _ in range(height)]
    
    powerup_qbox_count = 0
    max_powerup_boxes = 2 if diff < 0.6 else 1  # Rare power-ups (max 1 or 2 per level)
    
    current_ground_y = 12 
    
    # 1. Safe Starting Zone (15 columns of flat ground)
    for x in range(15):
        for y in range(current_ground_y, height):
            grid[y][x] = 'X'
            
    # Welcome question blocks (mostly coins 'Q', 1 rare power-up '?')
    grid[current_ground_y - 4][6] = 'Q'  # Coin ? block
    grid[current_ground_y - 4][8] = '?'  # Rare Power-up ? block
    grid[current_ground_y - 5][7] = 'o'
    grid[current_ground_y - 6][7] = 'o'
    powerup_qbox_count += 1
    
    col = 15

    features_pool = [
        'piranha_pipe_garden', 
        'brick_stairs', 
        'floating_canopy', 
        'coin_vault', 
        'enemy_patrol', 
        'pyramid_climb'
    ]

    while col < width - 35:
        segment_len = random.randint(14, 20)
        
        # Terrain height variation
        if random.random() < 0.35:
            current_ground_y = max(10, min(13, current_ground_y + random.choice([-1, 1])))

        # Draw ground floor
        for x in range(col, min(col + segment_len, width - 35)):
            for y in range(current_ground_y, height):
                grid[y][x] = 'X'

        # Feature selection weighted by target difficulty
        if diff < 0.35:
            weights = [0.25, 0.25, 0.25, 0.15, 0.05, 0.05]
        elif diff < 0.70:
            weights = [0.25, 0.15, 0.15, 0.05, 0.25, 0.15]
        else:
            weights = [0.30, 0.10, 0.10, 0.02, 0.33, 0.15]

        feature = random.choices(features_pool, weights=weights)[0]

        if feature == 'piranha_pipe_garden':
            num_pipes = random.randint(1, 2 if diff < 0.6 else 3)
            for p in range(num_pipes):
                p_height = random.randint(2, 4 if diff > 0.5 else 3)
                px = col + 3 + (p * 5)
                
                if px + 1 < col + segment_len - 2:
                    # Clear air buffer around pipe
                    for cx in range(px - 1, px + 3):
                        for cy in range(current_ground_y - p_height - 2, current_ground_y):
                            if 0 <= cx < width and 0 <= cy < height:
                                grid[cy][cx] = '-'
                                
                    # Base ground floor beneath pipe
                    for gy in range(current_ground_y, height):
                        grid[gy][px] = 'X'
                        grid[gy][px + 1] = 'X'

                    # Determine if Pipe has Piranha Flower (higher chance at medium/high difficulty)
                    has_piranha = (diff > 0.20) and (random.random() < (0.4 + diff * 0.5))

                    # Pipe Top Row (T & t for Piranha Flower Pipe, t & t for Clean Pipe)
                    if has_piranha:
                        grid[current_ground_y - p_height][px] = 'T'     # Piranha Flower Pipe Top Left
                        grid[current_ground_y - p_height][px + 1] = 't' # Pipe Top Right
                    else:
                        grid[current_ground_y - p_height][px] = 't'     # Clean Pipe Top Left
                        grid[current_ground_y - p_height][px + 1] = 't' # Clean Pipe Top Right
                    
                    # Pipe Body Rows
                    for py in range(current_ground_y - p_height + 1, current_ground_y):
                        grid[py][px] = 't'
                        grid[py][px + 1] = 't'
                        
                    # Reward coin above clean pipe
                    if not has_piranha and random.random() < 0.6:
                        grid[current_ground_y - p_height - 2][px] = 'o'
                        grid[current_ground_y - p_height - 2][px + 1] = 'o'

        elif feature == 'brick_stairs':
            stair_h = random.randint(2, 4)
            sx = col + 2
            for step in range(stair_h):
                if sx + step < col + segment_len - 2:
                    for sy in range(current_ground_y - step - 1, current_ground_y):
                        grid[sy][sx + step] = 'X'
            top_x = sx + stair_h
            if top_x < col + segment_len - 2:
                # Mostly coin ? blocks 'Q', rare mushroom '?'
                if powerup_qbox_count < max_powerup_boxes and random.random() < 0.3:
                    grid[current_ground_y - stair_h - 2][top_x] = '?'
                    powerup_qbox_count += 1
                else:
                    grid[current_ground_y - stair_h - 2][top_x] = 'Q'

        elif feature == 'floating_canopy':
            plat_y = current_ground_y - random.randint(3, 5)
            plat_len = random.randint(4, 7)
            plat_x = col + 2
            
            for px in range(plat_x, min(plat_x + plat_len, col + segment_len - 2)):
                if random.random() < 0.3:
                    grid[plat_y][px] = 'Q'  # Coin question block
                elif random.random() < 0.05 and powerup_qbox_count < max_powerup_boxes:
                    grid[plat_y][px] = '?'  # Rare mushroom power-up
                    powerup_qbox_count += 1
                else:
                    grid[plat_y][px] = 'S'  # Normal brick block
                
                if random.random() < 0.5:
                    grid[plat_y - 1][px] = 'o'

        elif feature == 'coin_vault':
            vault_x = col + 3
            vault_y = current_ground_y - 4
            for vx in range(vault_x, min(vault_x + 5, col + segment_len - 2)):
                grid[vault_y][vx] = 'Q' if (vx % 2 == 0) else 'S'
                grid[vault_y - 1][vx] = 'o'

        elif feature == 'enemy_patrol':
            enemy_count = random.randint(1, 2) if diff < 0.35 else (random.randint(2, 4) if diff < 0.70 else random.randint(3, 6))
            for e in range(enemy_count):
                ex = col + 3 + (e * 3)
                if ex < col + segment_len - 2:
                    enemy_type = 'g'
                    if diff > 0.30 and random.random() < 0.45:
                        enemy_type = 'k'
                    elif diff > 0.60 and random.random() < 0.50:
                        enemy_type = 'r'
                    grid[current_ground_y - 1][ex] = enemy_type

        elif feature == 'pyramid_climb':
            pyr_h = random.randint(3, 5)
            start_x = col + 2
            for step in range(pyr_h):
                if start_x + step < col + segment_len - 2:
                    for sy in range(current_ground_y - step - 1, current_ground_y):
                        grid[sy][start_x + step] = 'X'
            desc_x = start_x + pyr_h
            for step in range(pyr_h - 1, -1, -1):
                if desc_x + (pyr_h - 1 - step) < col + segment_len - 2:
                    for sy in range(current_ground_y - step - 1, current_ground_y):
                        grid[sy][desc_x + (pyr_h - 1 - step)] = 'X'

        # Controlled Pit Gaps
        gap_probability = 0.05 + (diff * 0.45)
        if random.random() < gap_probability:
            gap_width = 2 if diff < 0.45 else (3 if diff < 0.75 else 4)
            
            if gap_width >= 4 and random.random() < 0.5:
                col += segment_len
                island_x = col + 1
                grid[current_ground_y - 1][island_x] = 'S'
                grid[current_ground_y - 1][island_x + 1] = 'S'
                grid[current_ground_y - 2][island_x] = 'o'
                col += gap_width + 1
            else:
                col += segment_len + gap_width
        else:
            col += segment_len

    # --- ENDING SEQUENCE (Staircase, Flagpole, Castle) ---
    end_ground_y = 12
    for x in range(width - 35, width):
        for y in range(end_ground_y, height):
            grid[y][x] = 'X'

    stair_start = width - 25
    for step in range(8):
        sx = stair_start + step
        for sy in range(end_ground_y - step, end_ground_y):
            grid[sy][sx] = 'X'

    flag_x = stair_start + 12
    for fy in range(end_ground_y - 10, end_ground_y):
        grid[fy][flag_x] = 'F'
    grid[end_ground_y - 10][flag_x - 1] = 'o'

    castle_x = flag_x + 4
    for cx in range(castle_x, castle_x + 5):
        for cy in range(end_ground_y - 4, end_ground_y):
            grid[cy][cx] = 'X'

    return "\n".join(["".join(row) for row in grid])

def generate_mario_level(target_difficulty, width=220, height=16, seed=None, max_diff_error=0.05, max_attempts=50):
    """
    Generates a Mario level formatted for Mario-AI-Framework.
    Enforces that abs(estimated_difficulty - target_difficulty) <= 0.05.
    If difficulty error is > 0.05, automatically regenerates until tolerance is satisfied.
    """
    best_level = None
    best_error = 999.0

    for attempt in range(max_attempts):
        cur_seed = None if seed is None else (seed + attempt * 17)
        level_text = _build_raw_level_grid(target_difficulty, width=width, height=height, seed=cur_seed)
        est_diff = calculate_difficulty(level_text)
        error = abs(est_diff - target_difficulty)

        if error <= max_diff_error:
            return level_text

        if error < best_error:
            best_error = error
            best_level = level_text

    return best_level

def tweak_level_for_dda(base_level_text, dda_delta):
    """
    Applies small DDA micro-adjustments to an existing level layout when retrying,
    preserving the overall layout while easing or increasing challenge subtly.

    :param base_level_text: str representation of the previous level layout
    :param dda_delta: float difficulty adjustment (-0.10 to +0.10)
    :return: (modified_level_text, list_of_structural_changes_made)
    """
    lines = [list(line) for line in base_level_text.splitlines() if line.strip()]
    if not lines:
        return base_level_text, ["No layout changes"]

    height = len(lines)
    width = len(lines[0])
    changes_made = []

    if dda_delta < -0.01:
        # --- EASE CHALLENGE ---
        # 1. Narrow pit gaps in bottom ground row
        ground_y = height - 1
        gap_starts = []
        in_gap = False
        start_x = 0
        for x in range(width):
            if lines[ground_y][x] == '-':
                if not in_gap:
                    in_gap = True
                    start_x = x
            else:
                if in_gap:
                    in_gap = False
                    gap_len = x - start_x
                    if gap_len >= 3:
                        gap_starts.append((start_x, gap_len))

        if gap_starts:
            # Fill 1 column of the first wide gap to narrow it
            gx, glen = random.choice(gap_starts)
            fill_x = gx + glen - 1
            for y in range(ground_y - 1, height):
                lines[y][fill_x] = 'X'
            changes_made.append(f"Narrowed pit gap at col {gx} (width reduced from {glen} to {glen-1})")

        # 2. Reduce piranha flowers
        piranha_locs = []
        for y in range(height):
            for x in range(width):
                if lines[y][x] == 'T':
                    piranha_locs.append((y, x))
        
        if piranha_locs:
            py, px = random.choice(piranha_locs)
            lines[py][px] = 't'  # Change flower pipe top to clean pipe top
            changes_made.append(f"Removed 1 Piranha Flower Pipe at col {px}")

        # 3. Reduce enemy density
        enemy_locs = []
        for y in range(height):
            for x in range(width):
                if lines[y][x] in ['g', 'k', 'r']:
                    enemy_locs.append((y, x))

        if enemy_locs and len(changes_made) < 3:
            # Convert 1-2 enemies to coins
            num_to_remove = min(2, len(enemy_locs))
            chosen = random.sample(enemy_locs, num_to_remove)
            for ey, ex in chosen:
                lines[ey][ex] = 'o'
            changes_made.append(f"Converted {num_to_remove} enemy patrol(s) to reward coins")

        # 4. Add a mushroom powerup block if none added yet
        if len(changes_made) == 0:
            brick_locs = [(y, x) for y in range(height) for x in range(width) if lines[y][x] == 'S']
            if brick_locs:
                by, bx = random.choice(brick_locs)
                lines[by][bx] = '?'
                changes_made.append(f"Converted brick at col {bx} into a Mushroom Power-Up ? block")
            else:
                changes_made.append("Slightly lowered terrain hazards")

    elif dda_delta > 0.01:
        # --- INCREASE CHALLENGE ---
        # 1. Convert a clean pipe to a Piranha Flower pipe
        clean_pipes = []
        for y in range(1, height - 1):
            for x in range(width - 1):
                if lines[y][x] == 't' and lines[y][x+1] == 't' and lines[y-1][x] == '-':
                    clean_pipes.append((y, x))
        
        if clean_pipes:
            py, px = random.choice(clean_pipes)
            lines[py][px] = 'T'
            changes_made.append(f"Added Piranha Flower to pipe at col {px}")

        # 2. Add an enemy patrol
        ground_y = height - 1
        flat_ground = [x for x in range(20, width - 40) if lines[ground_y][x] == 'X' and lines[ground_y - 1][x] == '-']
        if flat_ground:
            ex = random.choice(flat_ground)
            lines[ground_y - 1][ex] = 'g'
            changes_made.append(f"Added extra Goomba enemy patrol at col {ex}")
        
        if not changes_made:
            changes_made.append("Slightly increased enemy vigilance")
    else:
        changes_made.append("Retained exact level layout structure for retry")

    modified_text = "\n".join(["".join(row) for row in lines])
    return modified_text, changes_made

if __name__ == "__main__":
    lvl1 = generate_mario_level(0.5)
    print("Level Piranha Pipes ('T'):", lvl1.count('T'))
    print("Level Coin ? Blocks ('Q'):", lvl1.count('Q'))
    print("Level Rare Mushroom ? Blocks ('?'):", lvl1.count('?'))