from flask import Flask, render_template, request, jsonify
from pipeline import run_pipeline_sequence, generate_single_level_pipeline
from dda import DynamicDifficultyAdjuster
from generator import generate_mario_level, tweak_level_for_dda
from estimator import calculate_difficulty
import os
import subprocess
import time

app = Flask(__name__, template_folder='templates', static_folder='static')

MARIO_DIR = os.path.abspath("Mario-AI-Framework")

PRESETS = {
    "linear_ramp": {
        "name": "Linear Ramp (Progressive)",
        "curve": [0.2, 0.35, 0.5, 0.65, 0.8]
    },
    "mid_spike": {
        "name": "Spike & Recovery (Pacing Arc)",
        "curve": [0.25, 0.45, 0.85, 0.35, 0.70]
    },
    "wave_pacing": {
        "name": "Sawtooth Pacing Wave",
        "curve": [0.3, 0.6, 0.4, 0.75, 0.5, 0.85]
    },
    "boss_rush": {
        "name": "Climax Peak (Boss Rush)",
        "curve": [0.3, 0.4, 0.55, 0.7, 0.95]
    }
}

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/api/presets', methods=['GET'])
def get_presets():
    return jsonify(PRESETS)

@app.route('/api/generate-sequence', methods=['POST'])
def generate_sequence():
    data = request.get_json() or {}
    curve = data.get("curve", [0.25, 0.45, 0.65, 0.80, 0.50])
    player_skill = data.get("player_skill", "average")
    max_variance = data.get("max_variance", 0.10)

    # Normalize input values to 0.0 - 1.0 if provided on 0 - 100 scale
    normalized_curve = [float(v) / 100.0 if float(v) > 1.0 else float(v) for v in curve]
    
    results = run_pipeline_sequence(normalized_curve, dda_variance=max_variance, player_skill=player_skill)
    return jsonify({
        "status": "Success",
        "data": results
    })

@app.route('/api/watch-ai-play', methods=['POST'])
def watch_ai_play():
    """Launches Java window with Robin Baumgarten AI agent solving the level in real-time."""
    data = request.get_json() or {}
    level_text = data.get("level_text", None)
    target_diff = float(data.get("target_difficulty", 0.5))
    level_idx = data.get("level_index", 1)

    levels_dir = os.path.join(MARIO_DIR, "levels")
    os.makedirs(levels_dir, exist_ok=True)
    
    timestamp = int(time.time())
    rel_path = f"levels/level_ai_vis_{level_idx}_{timestamp}.txt"
    abs_path = os.path.abspath(os.path.join(MARIO_DIR, rel_path))

    if not level_text:
        level_text = generate_mario_level(target_diff)

    with open(abs_path, "w") as f:
        f.write(level_text)

    theme_id = (level_idx - 1) % 3
    run_cmd = [
        "java", "-cp", "bin", "PlayLevel",
        abs_path, "validate_vis", str(theme_id), "0"
    ]

    try:
        print(f"[API] Launching AI Playback Window for Level {level_idx} (Target Diff: {target_diff:.2f})...", flush=True)
        flags = subprocess.CREATE_NEW_CONSOLE if os.name == 'nt' else 0
        subprocess.Popen(run_cmd, cwd=MARIO_DIR, creationflags=flags)
        return jsonify({
            "status": "Success",
            "message": f"AI playback window launched for Level {level_idx}!"
        })
    except Exception as e:
        print(f"[API ERROR] Failed to launch AI playback: {e}", flush=True)
        return jsonify({"status": "Error", "message": str(e)}), 500

@app.route('/api/play-human-level', methods=['POST'])
def play_human_level():
    """Launches Java interactive game window for human player."""
    data = request.get_json() or {}
    level_index = int(data.get("level_index", 1))
    target_difficulty = float(data.get("target_difficulty", 0.5))
    lives = int(data.get("lives", 3))
    coins = int(data.get("coins", 0))
    mario_mode = int(data.get("mario_mode", 0))
    is_retry = bool(data.get("is_retry", False))
    prev_level_text = data.get("prev_level_text", None)
    retry_dda_delta = float(data.get("retry_dda_delta", -0.05))

    levels_dir = os.path.join(MARIO_DIR, "levels")
    os.makedirs(levels_dir, exist_ok=True)
    
    res_path = os.path.join(levels_dir, "last_result.txt")
    if os.path.exists(res_path):
        try:
            os.remove(res_path)
        except Exception:
            pass

    timestamp = int(time.time())
    rel_path = f"levels/level_human_{level_index}_{timestamp}.txt"
    abs_path = os.path.abspath(os.path.join(MARIO_DIR, rel_path))

    structural_changes = []
    if is_retry and prev_level_text:
        level_text, structural_changes = tweak_level_for_dda(prev_level_text, retry_dda_delta)
    else:
        level_text = generate_mario_level(target_difficulty)
        structural_changes = ["Generated initial level layout tuned to target difficulty"]

    with open(abs_path, "w") as f:
        f.write(level_text)

    theme_id = (level_index - 1) % 3
    run_cmd = [
        "java", "-cp", "bin", "PlayLevel",
        abs_path, "play", str(theme_id), str(mario_mode), str(lives), str(coins)
    ]

    try:
        print(f"[API] Launching Interactive Java Mario Window for World 1-{level_index} (Lives: {lives}, Mode: {mario_mode})...", flush=True)
        flags = subprocess.CREATE_NEW_CONSOLE if os.name == 'nt' else 0
        subprocess.Popen(run_cmd, cwd=MARIO_DIR, creationflags=flags)
        return jsonify({
            "status": "Success",
            "message": f"Interactive Java Mario window launched for World 1-{level_index}!",
            "played_level": {
                "level_index": level_index,
                "target_difficulty": target_difficulty,
                "level_text": level_text,
                "estimated_difficulty": calculate_difficulty(level_text)
            },
            "structural_changes": structural_changes
        })
    except Exception as e:
        print(f"[API ERROR] Failed to launch interactive game window: {e}", flush=True)
        return jsonify({"status": "Error", "message": str(e)}), 500

@app.route('/api/check-session-result', methods=['POST'])
def check_session_result():
    """Polls for completion of human interactive play in Java window."""
    data = request.get_json() or {}
    next_designer_target = float(data.get("next_designer_target", 0.5))
    
    res_path = os.path.join(MARIO_DIR, "levels", "last_result.txt")
    if not os.path.exists(res_path):
        return jsonify({"status": "Waiting", "message": "Game in progress..."})

    stdout_text = ""
    try:
        with open(res_path, "r", encoding="utf-8", errors="replace") as f:
            stdout_text = f.read()
    except Exception:
        return jsonify({"status": "Waiting", "message": "Reading result..."})

    if "SESSION_UPDATE:" not in stdout_text:
        return jsonify({"status": "Waiting", "message": "Game in progress..."})

    try:
        os.remove(res_path)
    except Exception:
        pass

    session_update = {
        "won": False,
        "mario_mode": 0,
        "lives": 3,
        "coins": 0,
        "time_taken": 30.0,
        "completion_pct": 0.0,
        "kills": 0,
        "total_enemies": 5,
        "hurts": 0,
        "jumps": 0
    }

    for line in stdout_text.splitlines():
        if line.startswith("SESSION_UPDATE:"):
            parts = dict(item.split("=") for item in line.replace("SESSION_UPDATE:", "").split(":"))
            session_update["won"] = parts.get("WON", "false").lower() == "true"
            session_update["mario_mode"] = int(parts.get("MODE", 0))
            session_update["lives"] = int(parts.get("LIVES", 3))
            session_update["coins"] = int(parts.get("COINS", 0))
            session_update["kills"] = int(parts.get("KILLS", 0))
            session_update["total_enemies"] = int(parts.get("TOTAL_ENEMIES", 5))
            session_update["hurts"] = int(parts.get("HURTS", 0))
            session_update["jumps"] = int(parts.get("JUMPS", 0))
            if "COMPLETION" in parts:
                try:
                    session_update["completion_pct"] = float(parts["COMPLETION"])
                except ValueError:
                    pass

    dda = DynamicDifficultyAdjuster(max_variance=0.10)
    adjustment = dda.calculate_adjustment(next_designer_target, {
        "won": session_update["won"],
        "lives_lost": 0 if session_update["won"] else 1,
        "completion_pct": session_update["completion_pct"] if session_update["completion_pct"] > 0 else (1.0 if session_update["won"] else 0.6),
        "time_taken": 30.0,
        "target_time": 40.0,
        "mario_mode": session_update["mario_mode"]
    })

    if session_update["won"]:
        session_update["struggle_reason"] = "Course Clear! Flagpole reached."
    else:
        pct_int = int(session_update["completion_pct"] * 100)
        session_update["struggle_reason"] = f"Died at {pct_int}% distance."

    next_level = generate_single_level_pipeline(adjustment["adjusted_target"])

    return jsonify({
        "status": "Success",
        "session_update": session_update,
        "dda_adjustment": adjustment,
        "next_level": next_level
    })

if __name__ == '__main__':
    os.makedirs('templates', exist_ok=True)
    os.makedirs(os.path.join(MARIO_DIR, 'levels'), exist_ok=True)
    print("============================================================")
    print(" MARIO PCG & DDA ADAPTIVE ENGINE SERVER IS READY")
    print(" Access Web UI at: http://127.0.0.1:5000")
    print("============================================================")
    app.run(host='0.0.0.0', port=5000, debug=False, use_reloader=False)