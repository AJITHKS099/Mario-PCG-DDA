import random
import time

from estimator import calculate_difficulty
from vglc_trainer import get_vglc_model

def _build_raw_level_grid(target_difficulty, width=220, height=16, seed=None):
    """
    Generates a level layout using the VGLC 2nd-order Markov Chain model trained on 31 Super Mario Bros levels.
    """
    vglc_model = get_vglc_model()
    return vglc_model.generate_level_grid(target_difficulty=target_difficulty, width=width, height=height, seed=seed)

def generate_mario_level(target_difficulty, width=220, height=16, seed=None, max_diff_error=0.05, max_attempts=50):
    """
    Generates a Mario level formatted for Mario-AI-Framework.
    Enforces that abs(estimated_difficulty - target_difficulty) <= 0.05.
    If difficulty error is > 0.05, automatically regenerates until tolerance is satisfied.
    """
    best_level = None
    best_error = 999.0

    for attempt in range(max_attempts):
        cur_seed = None if seed is None else (seed + attempt * 17)
        level_text = _build_raw_level_grid(target_difficulty, width=width, height=height, seed=cur_seed)
        est_diff = calculate_difficulty(level_text)
        error = abs(est_diff - target_difficulty)

        if error <= max_diff_error:
            return level_text

        if error < best_error:
            best_error = error
            best_level = level_text

    return best_level

def tweak_level_for_dda(base_level_text, dda_delta):
    """
    Applies small DDA micro-adjustments to an existing level layout when retrying,
    preserving the overall layout while easing or increasing challenge subtly.

    :param base_level_text: str representation of the previous level layout
    :param dda_delta: float difficulty adjustment (-0.10 to +0.10)
    :return: (modified_level_text, list_of_structural_changes_made)
    """
    lines = [list(line) for line in base_level_text.splitlines() if line.strip()]
    if not lines:
        return base_level_text, ["No layout changes"]

    height = len(lines)
    width = len(lines[0])
    changes_made = []

    if dda_delta < -0.01:
        # --- EASE CHALLENGE ---
        # 1. Narrow pit gaps in bottom ground row
        ground_y = height - 1
        gap_starts = []
        in_gap = False
        start_x = 0
        for x in range(width):
            if lines[ground_y][x] == '-':
                if not in_gap:
                    in_gap = True
                    start_x = x
            else:
                if in_gap:
                    in_gap = False
                    gap_len = x - start_x
                    if gap_len >= 3:
                        gap_starts.append((start_x, gap_len))

        if gap_starts:
            # Fill 1 column of the first wide gap to narrow it
            gx, glen = random.choice(gap_starts)
            fill_x = gx + glen - 1
            for y in range(ground_y - 1, height):
                lines[y][fill_x] = 'X'
            changes_made.append(f"Narrowed pit gap at col {gx} (width reduced from {glen} to {glen-1})")

        # 2. Reduce piranha flowers
        piranha_locs = []
        for y in range(height):
            for x in range(width):
                if lines[y][x] == 'T':
                    piranha_locs.append((y, x))
        
        if piranha_locs:
            py, px = random.choice(piranha_locs)
            lines[py][px] = 't'  # Change flower pipe top to clean pipe top
            changes_made.append(f"Removed 1 Piranha Flower Pipe at col {px}")

        # 3. Reduce enemy density
        enemy_locs = []
        for y in range(height):
            for x in range(width):
                if lines[y][x] in ['g', 'k', 'r']:
                    enemy_locs.append((y, x))

        if enemy_locs and len(changes_made) < 3:
            # Convert 1-2 enemies to coins
            num_to_remove = min(2, len(enemy_locs))
            chosen = random.sample(enemy_locs, num_to_remove)
            for ey, ex in chosen:
                lines[ey][ex] = 'o'
            changes_made.append(f"Converted {num_to_remove} enemy patrol(s) to reward coins")

        # 4. Add a mushroom powerup block if none added yet
        if len(changes_made) == 0:
            brick_locs = [(y, x) for y in range(height) for x in range(width) if lines[y][x] == 'S']
            if brick_locs:
                by, bx = random.choice(brick_locs)
                lines[by][bx] = '?'
                changes_made.append(f"Converted brick at col {bx} into a Mushroom Power-Up ? block")
            else:
                changes_made.append("Slightly lowered terrain hazards")

    elif dda_delta > 0.01:
        # --- INCREASE CHALLENGE ---
        # 1. Convert a clean pipe to a Piranha Flower pipe
        clean_pipes = []
        for y in range(1, height - 1):
            for x in range(width - 1):
                if lines[y][x] == 't' and lines[y][x+1] == 't' and lines[y-1][x] == '-':
                    clean_pipes.append((y, x))
        
        if clean_pipes:
            py, px = random.choice(clean_pipes)
            lines[py][px] = 'T'
            changes_made.append(f"Added Piranha Flower to pipe at col {px}")

        # 2. Add an enemy patrol
        ground_y = height - 1
        flat_ground = [x for x in range(20, width - 40) if lines[ground_y][x] == 'X' and lines[ground_y - 1][x] == '-']
        if flat_ground:
            ex = random.choice(flat_ground)
            lines[ground_y - 1][ex] = 'g'
            changes_made.append(f"Added extra Goomba enemy patrol at col {ex}")
        
        if not changes_made:
            changes_made.append("Slightly increased enemy vigilance")
    else:
        changes_made.append("Retained exact level layout structure for retry")

    modified_text = "\n".join(["".join(row) for row in lines])
    return modified_text, changes_made

if __name__ == "__main__":
    lvl1 = generate_mario_level(0.5)
    print("Level Piranha Pipes ('T'):", lvl1.count('T'))
    print("Level Coin ? Blocks ('Q'):", lvl1.count('Q'))
    print("Level Rare Mushroom ? Blocks ('?'):", lvl1.count('?'))