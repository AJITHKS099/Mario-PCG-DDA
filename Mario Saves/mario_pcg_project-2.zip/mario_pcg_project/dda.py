"""
Dynamic Difficulty Adjustment (DDA) Engine for Mario PCG.
Calculates real-time difficulty adjustments based on player performance metrics,
strictly enforcing a 10% (0.10) maximum variance bound relative to the designer's target curve.
"""

class DynamicDifficultyAdjuster:
    def __init__(self, max_variance=0.10):
        """
        :param max_variance: Maximum allowed delta from designer baseline (default 0.10 = 10%)
        """
        self.max_variance = max_variance

    def calculate_adjustment(self, designer_target, player_performance):
        """
        Calculates the new target difficulty for the next level based on player performance.

        :param designer_target: float between 0.0 and 1.0 (the designer's original target)
        :param player_performance: dict containing:
            - 'won': bool (True if course clear, False if died/lost)
            - 'lives_lost': int (0, 1, 2...)
            - 'completion_pct': float (0.0 to 1.0)
            - 'time_taken': float (seconds)
            - 'target_time': float (expected duration for average player)
            - 'mario_mode': int (0=Small, 1=Super, 2=Fire)
        :return: dict with 'adjusted_target', 'delta', 'reason'
        """
        won = player_performance.get('won', True)
        lives_lost = player_performance.get('lives_lost', 0 if won else 1)
        completion_pct = player_performance.get('completion_pct', 1.0 if won else 0.5)
        time_taken = player_performance.get('time_taken', 30.0)
        target_time = player_performance.get('target_time', 45.0)
        mario_mode = player_performance.get('mario_mode', 0)

        # Base performance score from -1.0 (very poor) to +1.0 (flawless)
        if won:
            # Player cleared level
            time_factor = (target_time - time_taken) / max(target_time, 1.0)
            time_factor = max(-0.5, min(0.5, time_factor))  # Clamp [-0.5, +0.5]

            power_bonus = 0.2 if mario_mode > 0 else 0.0
            
            raw_performance = 0.4 + (time_factor * 0.4) + power_bonus
        else:
            # Player failed level
            raw_performance = -0.5 - (0.2 * lives_lost) + (completion_pct * 0.3)

        # Scale raw performance into DDA delta bounded within [-max_variance, +max_variance]
        delta = raw_performance * self.max_variance
        delta = max(-self.max_variance, min(self.max_variance, delta))

        # Apply delta to designer target and clamp within [0.0, 1.0] and [target-max_var, target+max_var]
        min_allowed = max(0.0, designer_target - self.max_variance)
        max_allowed = min(1.0, designer_target + self.max_variance)

        adjusted_target = round(max(min_allowed, min(max_allowed, designer_target + delta)), 3)
        actual_delta = round(adjusted_target - designer_target, 3)

        # Generate human-readable explanation
        if actual_delta > 0.01:
            reason = f"Player performed well (+{actual_delta*100:.1f}% difficulty shift). Increasing challenge."
        elif actual_delta < -0.01:
            reason = f"Player struggled ({actual_delta*100:.1f}% difficulty shift). Easing challenge."
        else:
            reason = "Player performance matched target expectations. Maintaining designer curve."

        # Generate specific structural design modification notes
        dda_changes = []
        if actual_delta < -0.01:
            dda_changes.append(f"Reduced hazard density (Target difficulty lowered from {designer_target*100:.0f}% to {adjusted_target*100:.0f}%)")
            dda_changes.append("Narrowed maximum gap widths for safer platforming")
            dda_changes.append("Decreased enemy patrol frequency & Piranha Pipe spawns")
            dda_changes.append("Added +1 Mushroom Power-Up Question Block")
        elif actual_delta > 0.01:
            dda_changes.append(f"Increased challenge density (Target difficulty raised from {designer_target*100:.0f}% to {adjusted_target*100:.0f}%)")
            dda_changes.append("Increased Koopa & Piranha Flower Pipe frequency")
            dda_changes.append("Slightly widened platforming pit gaps")
        else:
            dda_changes.append("Maintained target difficulty curve without structural shifts")

        return {
            "designer_target": designer_target,
            "adjusted_target": adjusted_target,
            "delta": actual_delta,
            "delta_pct": f"{actual_delta * 100:+.1f}%",
            "raw_performance": round(raw_performance, 3),
            "reason": reason,
            "dda_changes": dda_changes
        }

if __name__ == "__main__":
    dda = DynamicDifficultyAdjuster(max_variance=0.10)
    print("Testing DDA Engine:")
    print("Flawless win at target 0.50:", dda.calculate_adjustment(0.50, {'won': True, 'time_taken': 20.0, 'mario_mode': 2}))
    print("Loss at target 0.50:", dda.calculate_adjustment(0.50, {'won': False, 'lives_lost': 1, 'completion_pct': 0.4}))
